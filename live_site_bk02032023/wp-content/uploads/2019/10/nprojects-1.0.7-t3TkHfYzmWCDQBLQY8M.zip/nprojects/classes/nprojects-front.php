<?php
/**
 * WARNING: This file is part of the Projects plugin. DO NOT edit
 * this file under any circumstances.
 */

/**
 * Prevent direct access to this file
 */
defined( 'ABSPATH' ) or die();

/**
 * @package  Projects
 * @author   Binh Pham Thanh <binhpham@linethemes.com>
 */
final class nProjects_Front extends nProjects_Base
{
	protected function __construct() {

	}
}
